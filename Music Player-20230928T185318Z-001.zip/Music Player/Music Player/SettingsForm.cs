﻿namespace Music_Player
{
    internal class SettingsForm
    {
        public SettingsForm()
        {
        }

        public object VolumeTrackbar { get; internal set; }
    }
}